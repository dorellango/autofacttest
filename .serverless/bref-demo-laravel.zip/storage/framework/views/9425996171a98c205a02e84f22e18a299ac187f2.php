<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <?php if(auth()->user()->quizzes->isNotEmpty()): ?>
                <h1 class="text-gray-100 text-2xl mb-2">Hi! <span class="underline"><?php echo e(auth()->user()->name); ?></span> you are up to date 🔥🔥🔥 </h1>
                <h2 class="text-gray-600 text-2xl mb-6">Last quiz was <?php echo e($lastQuiz->created_at->format('d-m-Y H:m')); ?></h1>

                <div class="p-4 border border-dashed border-gray-800 bg-gray-900 text-gray-100 whitespace-normal"
                    style="overflow-wrap: break-word;">
                    <ul>
                        <li class="mb-2">
                            <h4 class="text-lg mb-2">¿Qué te gustaría que agregáramos al informe?</h4>
                            <p class="text-gray-600"><?php echo e($lastQuiz->suggestions); ?></p>
                        </li>
                        <li class="mb-2">
                            <h4 class="text-lg mb-2">¿La información es correcta?</h4>
                            <p class="text-gray-600"><?php echo e(trans('answers.is_the_information_right.' . $lastQuiz->is_the_information_right)); ?></p>
                        </li>
                        <li>
                            <h4 class="text-lg mb-2">¿Del 1 al 5, es rápido el sitio?</h4>
                            <p class="text-gray-600"><?php echo e($lastQuiz->fast_site); ?></p>
                        </li>
                    </ul>
                    <p class="border-t border-gray-700 pt-2 mt-2">
                        <?php echo e(json_encode($lastQuiz)); ?>

                    </p>
                </div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', new App\Quiz())): ?>
                <h1 class="text-gray-100 text-2xl mb-6">Hi! <span class="underline"><?php echo e(auth()->user()->name); ?></span> you should answer the monthly Quiz! 🗒</h1>

                <div class="card">
                    <div class="card-header">Let's see how much we improved</div>

                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('quizzes.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="mb-4">
                                <label for="suggestions" class="uppercase text-sm font-bold">¿Qué te gustaría que agregáramos al informe?</label>
                                <textarea class="form-control" id="suggestions" name="suggestions" rows="3" required></textarea>
                                <?php if ($errors->has('suggestions')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('suggestions'); ?>
                                    <span class="uppercase mt-2 text-red-600 text-sm" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <div class="mb-4">
                                <label for="is_the_information_right" class="uppercase text-sm font-bold" required>¿La información es correcta?</label>
                                <select class="form-control" id="is_the_information_right" name="is_the_information_right">
                                    <option value="yes">Si</option>
                                    <option value="no">No</option>
                                    <option value="both">Más o Menos</option>
                                </select>
                                <?php if ($errors->has('is_the_information_right')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('is_the_information_right'); ?>
                                    <span class="uppercase mt-2 text-red-600 text-sm" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <div class="mb-4">
                                <label for="fast_site" class="uppercase text-sm font-bold">¿Del 1 al 5, es rápido el sitio?</label>
                                <select class="form-control" id="fast_site" name="fast_site" required>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                </select>
                                <?php if ($errors->has('fast_site')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fast_site'); ?>
                                    <span class="uppercase mt-2 text-red-600 text-sm" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <button type="submit" class="bg-indigo-500 px-3 py-1 text-lg tracking-normal rounded text-indigo-200">
                                Send 👍
                            </button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/diegoorellana/Sites/autofacttest/resources/views/home.blade.php ENDPATH**/ ?>