<nav class="bg-gray-900 py-3 w-full shadow">
    <div class="container flex justify-between mx-auto">
        <a class="text-lg text-gray-100" href="<?php echo e(url('/')); ?>">
            <?php echo e(config('app.name', 'Laravel')); ?>

        </a>


        <div class="flex">
            <ul class="flex ml-auto">
                <?php if(auth()->guard()->guest()): ?>
                    <li class="ml-4">
                        <a class="text-gray-100" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                    </li>
                    <?php if(Route::has('register')): ?>
                        <li class="ml-4">
                            <a class="text-gray-100" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <li class="ml-4">
                        <a class="text-gray-100" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                    <?php if(auth()->user()->isAdmin()): ?>
                        <li class="mr-2 text-gray-600 font-bold ml-4 pl-4 border-l-2 border-gray-300">
                            👮‍ ADMIN
                        </li>
                        <li class="ml-2">
                            <a class="text-gray-100" href="<?php echo e(route('quizzes.index')); ?>"><?php echo e(__('Quizzes')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav><?php /**PATH /Users/diegoorellana/Sites/autofacttest/resources/views/partials/nav.blade.php ENDPATH**/ ?>