<?php

return [
    'is_the_information_right' => [
        'yes' => 'Si',
        'no' => 'No',
        'both' => 'Más o menos'
    ]
];
